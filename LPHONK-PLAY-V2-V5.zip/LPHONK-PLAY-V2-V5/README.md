# LPHONK PLAY V2–V5

Независимый игровой сайт: каталог, фильтры, избранное, Neon Arena realtime-комната, Supabase Auth, профили и таблица лидеров.

## Файлы
- `index.html` — сайт.
- `supabase-setup.sql` — таблицы, RLS-политики, триггер и рейтинг.
- `README.md` — инструкция.

## 1. Запуск без сервера
Открой `index.html` в браузере или опубликуй на GitHub Pages. Каталог и локальное избранное работают без регистрации. Онлайн-комната, регистрация и общий рейтинг пока будут показывать DEMO MODE.

## 2. Подключение Supabase
1. Создай проект на https://supabase.com/ (проверь актуальные условия бесплатного тарифа).
2. Открой SQL Editor → New query.
3. Вставь содержимое `supabase-setup.sql` и нажми Run.
4. В Supabase открой Project Settings → API (или Data API / API Keys в актуальном интерфейсе).
5. Скопируй Project URL и публичный `anon` / `publishable` key.
6. В `index.html` найди:
   `const SUPABASE_URL="YOUR_SUPABASE_PROJECT_URL";`
   `const SUPABASE_ANON_KEY="YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY";`
   Замени значения своими.
7. В Supabase Authentication → URL Configuration добавь адрес опубликованного GitHub Pages сайта в Site URL и Redirect URLs.
8. Убедись, что Realtime доступен в проекте. Neon Arena использует Supabase Realtime Presence/Broadcast.
9. Загрузить обновлённый `index.html` в GitHub-репозиторий и выполнить Commit changes.

## 3. Важная безопасность
- В браузер можно помещать только публичный anon/publishable key, если включены корректные RLS-политики.
- НИКОГДА не помещай `service_role`, secret key, пароль базы или приватные ключи в HTML/JavaScript.
- Для production-рейтинга нужен серверный контроль результатов и защита от накрутки. В этом стартовом проекте пользователь может отправить тестовые очки, поэтому рейтинг — демонстрационный, не соревновательный/денежный.
- Не собирай платёжные данные и не проси пароль от PlayStation Network.
- Не используй брендинг/логотипы Sony так, чтобы сайт выглядел официальным.

## 4. Ограничения
GitHub Pages — статический хостинг. Supabase обеспечивает аккаунты, базу и realtime-обмен. Этот проект не подключается к PSN, не запускает игры PS5 и не предоставляет чужие игровые файлы.
